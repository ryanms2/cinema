// import { ComponentPage } from './_components/component_page'

// export default function Page() {
//   return <ComponentPage />
// }
